using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using System.Windows.Forms;


public partial class BollaEmetti : System.Web.UI.Page
{

  protected void Page_Load(object sender, EventArgs e)
  {
		if (!IsPostBack)
		{
			myParameter p;

			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
			//	----------------------------------------------------------------------------------------------------
			myParameters parSocieta = new myParameters();
			if ((string)Session["flSocieta"] == "1")
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			parSocieta.Add((SqlParameter)p.CreateSQLParameter());
			//Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
			Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, (string)Session["utSocieta"]);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola societ�, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			if (cboSocieta.SelectedIndex == 0 && cboSocieta.Items.Count == 2) cboSocieta.SelectedIndex = 1;
			//if (cboSocieta.Items.Count == 2)
			//{ cboSocieta.SelectedIndex = 1; }
			//else
			//{ cboSocieta.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�; se non sono Admin solo la mia OrgUnit
			//	----------------------------------------------------------------------------------------------------
			myParameters parOrgUnit = new myParameters();
			if ((string)Session["flSocieta"] == "1" && cboSocieta.SelectedIndex == 0)
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
			else
			//{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
			{ p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString()); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono Admin posso gestire solo la mia OrgUnit
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flOrgUnit"] == "1")
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, ""); }
			else
			{ p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, (string)Session["dsOrgUnit"]); }
			parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
			//
			//Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
			Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, (string)Session["utOrgUnit"]);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta una sola Organization Unit, la si seleziona
			//	----------------------------------------------------------------------------------------------------
			if (cboOrgUnit.SelectedIndex == 0 && cboOrgUnit.Items.Count == 2) cboOrgUnit.SelectedIndex = 1;
			//if (cboOrgUnit.Items.Count == 2)
			//{ cboOrgUnit.SelectedIndex = 1; }
			//else
			//{ cboOrgUnit.SelectedIndex = 0; }

			//	----------------------------------------------------------------------------------------------------
			//	Se sono SuperAdmin posso gestire tutte le societ�, altrimenti solo quella dell'utente
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flSocieta"] == "1")
			{
				Panel_Societa.Visible = true;
			}
			else
			{
				cboSocieta.SelectedValue = (string)Session["dsCodSoc"];
				lblSocieta.Text = cboSocieta.SelectedItem.ToString();
				Visua_Societa.Visible = true;
			}

			//	----------------------------------------------------------------------------------------------------
			//	Se sono Admin posso gestire tutte le OrgUnit della mia societ�, altrimenti solo quella dell'utente
			//	----------------------------------------------------------------------------------------------------
			if ((string)Session["flOrgUnit"] == "1")
			{
				Panel_OrgUnit.Visible = true;
			}
			else
			{
				lblOrgUnit.Text = (string)Session["dsOrgUnit"];
				Visua_OrgUnit.Visible = true;
			}

			//	----------------------------------------------------------------------------------------------------
			//	Caricamento Centri di Costo per la OrgUnit selezionata
			//	----------------------------------------------------------------------------------------------------
			myParameters parCDC = new myParameters();
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
			//	----------------------------------------------------------------------------------------------------
			p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedItem.ToString());
			parCDC.Add((SqlParameter)p.CreateSQLParameter());
			//	----------------------------------------------------------------------------------------------------
			//	Se non sono Admin posso gestire solo la mia OrgUnit
			//	----------------------------------------------------------------------------------------------------
			p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, cboOrgUnit.SelectedItem.ToString());
			parCDC.Add((SqlParameter)p.CreateSQLParameter());
			//Helper.FillDropDownList(cboCentroCosto, DBHelper.GetSPDataSet("BOL_sp_EstraiCDC", parCDC), "deCDC", "deCDC", null, null, null);
			Helper.FillDropDownList(cboCentroCosto, DBHelper.GetSPDataSet("BOL_sp_EstraiCDC", parCDC), "deCDC", "deCDC", null, null, (string)Session["utCentroCosto"]);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta un solo Centro di Costo, lo si seleziona
			//	----------------------------------------------------------------------------------------------------
			if (cboCentroCosto.SelectedIndex == 0 && cboCentroCosto.Items.Count == 2) cboCentroCosto.SelectedIndex = 1;

			//	----------------------------------------------------------------------------------------------------
			//	Carico i rimanenti DropDownList
			//	----------------------------------------------------------------------------------------------------
			Helper.FillDropDownList(cboMotivo, DBHelper.GetSPDataSet("BOL_sp_EstraiMotivi"), "ceMotivo", "deMotivo", null, null, null);
			cboMotivo.SelectedIndex = 0;
			//
			Helper.FillDropDownList(cboSpedizione, DBHelper.GetSPDataSet("BOL_sp_EstraiLocalita"), "ceDipendenza", "deDipendenza", null, null, null);
			cboSpedizione.SelectedValue = (string)Session["dsSede"].ToString();
			//
			Helper.FillDropDownList(cboDestinazione, DBHelper.GetSPDataSet("BOL_sp_EstraiLocalita"), "ceDipendenza", "deDipendenza", null, null, null);
			cboDestinazione.SelectedIndex = 0;

			//	----------------------------------------------------------------------------------------------------
			//	Inizializzazione variabili di sessione per gestione bolla
			//	----------------------------------------------------------------------------------------------------
			Session["utSocieta"] = "";
			Session["utOrgUnit"] = "";
			Session["utCentroCosto"] = "";
		}
  }


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
		//	----------------------------------------------------------------------------------------------------
		//	Ricarico il DropDownList per Organization Unit
		//	----------------------------------------------------------------------------------------------------
		myParameter p;
		myParameters parOrgUnit = new myParameters();
		p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString());
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, "");
		parOrgUnit.Add((SqlParameter)p.CreateSQLParameter());
		Helper.FillDropDownList(cboOrgUnit, DBHelper.GetSPDataSet("BOL_sp_EstraiOrgUnit", parOrgUnit), "dsOrgUnit", "dsOrgUnit", null, null, null);
		//	----------------------------------------------------------------------------------------------------
		//	Se risulta una sola Organization Unit, la si seleziona e si carica il DropDownList per Centri di Costo
		//	----------------------------------------------------------------------------------------------------
		if (cboOrgUnit.Items.Count == 2)
		{
			cboOrgUnit.SelectedIndex = 1;
			myParameters parCDC = new myParameters();
			p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString());
			parCDC.Add((SqlParameter)p.CreateSQLParameter());
			p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, "");
			parCDC.Add((SqlParameter)p.CreateSQLParameter());
			Helper.FillDropDownList(cboCentroCosto, DBHelper.GetSPDataSet("BOL_sp_EstraiCDC", parCDC), "deCDC", "deCDC", null, null, null);
			//	----------------------------------------------------------------------------------------------------
			//	Se risulta un solo Centro di Costo, lo si seleziona
			//	----------------------------------------------------------------------------------------------------
			if (cboCentroCosto.Items.Count == 2) cboCentroCosto.SelectedIndex = 1;
		}
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Organization Unit
	//	----------------------------------------------------------------------------------------------------
	protected void cboOrgUnit_SelectedIndexChanged(object sender, EventArgs e)
	{
		//	----------------------------------------------------------------------------------------------------
		//	Ricarico il DropDownList per Centri di Costo
		//	----------------------------------------------------------------------------------------------------
		myParameter p;
		myParameters parCDC = new myParameters();
		p = new myParameter("@Societa", SqlDbType.Char, 2, cboSocieta.SelectedValue.ToString());
		parCDC.Add((SqlParameter)p.CreateSQLParameter());
		p = new myParameter("@Org_Unit", SqlDbType.VarChar, 50, cboOrgUnit.SelectedValue.ToString());
		parCDC.Add((SqlParameter)p.CreateSQLParameter());
		Helper.FillDropDownList(cboCentroCosto, DBHelper.GetSPDataSet("BOL_sp_EstraiCDC", parCDC), "deCDC", "deCDC", null, null, null);
		//	----------------------------------------------------------------------------------------------------
		//	Se risulta un solo Centro di Costo, lo si seleziona
		//	----------------------------------------------------------------------------------------------------
		if (cboCentroCosto.Items.Count == 2) cboCentroCosto.SelectedIndex = 1;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Funzioni CustomValidator per Motivo spedizione e Destinazione
	//	----------------------------------------------------------------------------------------------------
	protected void cvMotivo_Validate(object source, ServerValidateEventArgs args)
	{ 
		args.IsValid = (!string.IsNullOrEmpty(cboMotivo.SelectedValue.ToString()) && cboMotivo.SelectedValue.ToString() != "0");
	}

	protected void cvDestinazione_Validate(object source, ServerValidateEventArgs args)
	{ 
		args.IsValid =((!string.IsNullOrEmpty(cboDestinazione.SelectedValue.ToString())) || (!string.IsNullOrEmpty(txtDestinazione.Text.Trim())));
	}


	//	----------------------------------------------------------------------------------------------------
	//	Incremento numero e salvataggio dati bolla
	//	----------------------------------------------------------------------------------------------------
	public void cmdSalva_Click(object sender, EventArgs e)
	{
		if (Page.IsValid)
		{
			//	----------------------------------------------------------------------------------------------------
			//	Calcolo nuovo numero di bolla
			//	----------------------------------------------------------------------------------------------------
			Numeri Nuovo_Numero = new Numeri();
			Nuovo_Numero.AggiornaNumero(cboSocieta.SelectedValue.ToString(), DateTime.Today.Year.ToString());

			//	----------------------------------------------------------------------------------------------------
			//	Creazione nuovo record bolla
			//	----------------------------------------------------------------------------------------------------
			Bolla Nuova_Bolla = new Bolla();
			Nuova_Bolla.ceAnno = DateTime.Today.Year.ToString();
			Nuova_Bolla.ceProgr = Nuovo_Numero.nmNumero.ToString();
			
			// AF 23/09/2014
			if (cboSocieta.SelectedValue.ToString() == "AA") Nuova_Bolla.ceProgr = "SI250M" + Nuovo_Numero.nmNumero.ToString().Substring(1, 9);
			if (cboSocieta.SelectedValue.ToString() == "SP") Nuova_Bolla.ceProgr = "SI286M" + Nuovo_Numero.nmNumero.ToString().Substring(1, 9);

			// AF 16/02/2016
			if (cboSocieta.SelectedValue.ToString() == "BD") Nuova_Bolla.ceProgr = "SI295M" + Nuovo_Numero.nmNumero.ToString().Substring(1, 9);
			
			Nuova_Bolla.ceSocieta = cboSocieta.SelectedItem.ToString();
			Nuova_Bolla.deOrgUnit = cboOrgUnit.SelectedItem.ToString();
			Nuova_Bolla.ceUtente = (string)Session["ceGid"];
			Nuova_Bolla.flUtente = true;
			Nuova_Bolla.dtData = DateTime.Now;
			Nuova_Bolla.deCDC = cboCentroCosto.Text;
			Nuova_Bolla.ceMotivo = cboMotivo.SelectedValue.ToString();
			Nuova_Bolla.deRiferimento = txtRiferimento.Text;
			Nuova_Bolla.ceSpedizione = cboSpedizione.SelectedValue.ToString();
			Nuova_Bolla.ceDestinazione = cboDestinazione.SelectedValue.ToString();
			Nuova_Bolla.deDestinazione = txtDestinazione.Text;
			Nuova_Bolla.SalvaBolla();

			//	----------------------------------------------------------------------------------------------------
			//	Aggiornamento data ultima bolla su utente
			//	----------------------------------------------------------------------------------------------------
			Utente DataUtente = new Utente((string)Session["ceGid"]);
			DataUtente.dtBolla = Nuova_Bolla.dtData;
			DataUtente.AggData_Utente();

			//	----------------------------------------------------------------------------------------------------
			//	Invio Email assegnazione numero di bolla
			//	----------------------------------------------------------------------------------------------------
			// AF 23/09/2014
			//MandaMail mail = new MandaMail((string)Session["dsMainEmail"], (string)Session["dsMainEmail"], System.Configuration.ConfigurationManager.AppSettings["SubjectMail"] + Nuovo_Numero.nmNumero, Body_Mail(Nuova_Bolla.ceProgr, Nuova_Bolla.dtData));
			MandaMail mail = new MandaMail((string)Session["dsMainEmail"], (string)Session["dsMainEmail"], System.Configuration.ConfigurationManager.AppSettings["SubjectMail"] + Nuova_Bolla.ceProgr, Body_Mail(Nuova_Bolla.ceProgr, Nuova_Bolla.dtData));
			mail.SendMail_Bolla();
			
			// AF 23/09/2014 
			//lbl_Num_Bolla.Text = Nuovo_Numero.nmNumero;
			lbl_Num_Bolla.Text = Nuova_Bolla.ceProgr;

			Panel_Bolla.Visible = true;

			//	----------------------------------------------------------------------------------------------------
			//	Inizializzazione variabili rinnovo pagina
			//	----------------------------------------------------------------------------------------------------
			cboSocieta.SelectedIndex = 0;
			cboOrgUnit.SelectedIndex = 0;
			cboCentroCosto.SelectedIndex = 0;
			cboMotivo.SelectedIndex = 0;
			txtRiferimento.Text = "";
			cboDestinazione.SelectedIndex = 0;
			txtDestinazione.Text = "";
		}
	}

	//	----------------------------------------------------------------------------------------------------
	//	Preparazione testo della Email
	//	----------------------------------------------------------------------------------------------------
	private string Body_Mail(string numero, DateTime day_time)
	{ 
		System.Text.StringBuilder strBodyMail = new System.Text.StringBuilder();

		strBodyMail.Append("<table cellpadding='5' cellspacing='5'>");
		//
		strBodyMail.Append("<tr width='900px'>");
		strBodyMail.Append("<td colspan='2' align='center' style='background-color: #FF9933; font-family: Tahoma; font-size: x-small; font-weight: bold'>");
		strBodyMail.Append("Dati Bolla manuale  N.&nbsp;&nbsp;&nbsp;" + numero + "&nbsp;&nbsp;&nbsp;del&nbsp;&nbsp;&nbsp;" + day_time + "</td>");
		strBodyMail.Append("</tr>");
		strBodyMail.Append("<tr><td colspan='2'>&nbsp;</td></tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append("Societ�:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append(cboSocieta.SelectedItem.ToString() + "<br /></td>");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append("Org Unit:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append(cboOrgUnit.SelectedItem.ToString() + "<br /></td>");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append("Centro di Costo:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append(cboCentroCosto.Text + "<br /></td>");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append("Causale di spedizione:<br />");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small'>");
		strBodyMail.Append(cboMotivo.SelectedItem.Text + "<br />");
		strBodyMail.Append("</td>");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append("Riferimento di spedizione:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: X-small'>" );
		strBodyMail.Append(txtRiferimento.Text + "<br />");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: X-small; font-weight: bold'>");
		strBodyMail.Append("Luogo di spedizione:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: x-small'>");
		strBodyMail.Append(cboSpedizione.SelectedItem.Text + "<br />");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr valign='top'>");
		strBodyMail.Append("<td width='200px' style='font-family: Tahoma; font-size: x-small; font-weight: bold'>");
		strBodyMail.Append("Luogo di destinazione:");
		strBodyMail.Append("</td>");
		strBodyMail.Append("<td width='700px' style='font-family: Tahoma; font-size: x-small'>");
		if (cboDestinazione.SelectedIndex > 0) strBodyMail.Append(cboDestinazione.SelectedItem.Text + "<br />");
		if (txtDestinazione.Text != "") strBodyMail.Append(txtDestinazione.Text + "<br />");
		strBodyMail.Append("</tr>");
		//
		strBodyMail.Append("<tr><td colspan='2'>&nbsp;</td></tr>");
		//
		strBodyMail.Append("</table>");
		//
		strBodyMail.Append("<table>");
		strBodyMail.Append("<tr style='background-color: #FF9900; height: 1px'><td width='900px' style='height: 1px'></td></tr>");
		strBodyMail.Append("</table>");
		//
		return strBodyMail.ToString();
	}
}
