using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
//using System.Web.UI.MobileControls;

public partial class NumeriBolla : System.Web.UI.Page
{
  protected void Page_Load(object sender, EventArgs e)
  {

		if (!IsPostBack)
		{
			//	----------------------------------------------------------------------------------------------------
			//	Carico il DropDownList per Societ�
			//	----------------------------------------------------------------------------------------------------
			Carica_DropDown_Societa();
		}
  }

	protected void Page_LoadComplete(object sender, EventArgs e)
	{
		//if (Panel_Errore.Visible == false)
			BindData();
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico il DropDownList per Societ�
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void Carica_DropDown_Societa()
	{ 
		myParameter p;

		myParameters parSocieta = new myParameters();
		//	----------------------------------------------------------------------------------------------------
		//	Se non sono SuperAdmin posso gestire soltanto la mia Societ�
		//	----------------------------------------------------------------------------------------------------
		if ((string)Session["flSocieta"] == "1")
		{ p = new myParameter("@Societa", SqlDbType.Char, 2, ""); }
		else
		{ p = new myParameter("@Societa", SqlDbType.Char, 2, (string)Session["dsCodSoc"]); }
		parSocieta.Add((SqlParameter)p.CreateSQLParameter());
		//
		Helper.FillDropDownList(cboSocieta, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieta", parSocieta), "ceSocieta", "deSocieta", null, null, null);
		cboSocieta.SelectedIndex = 0;

		//	----------------------------------------------------------------------------------------------------
		//	Se sono SuperAdmin posso gestire tutte le societ�, altrimenti solo quella dell'utente
		//	----------------------------------------------------------------------------------------------------
		if ((string)Session["flSocieta"] == "1")
		{
			Panel_Societa.Visible = true;
		}
		else
		{
			cboSocieta.SelectedValue = (string)Session["dsCodSoc"];
			lblSocieta.Text = cboSocieta.SelectedItem.ToString();
			Visua_Societa.Visible = true;
		}

	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Carico dataset della tabella BOL_TB_NUMERI da mostrare nella datagrid
	//	----------------------------------------------------------------------------------------------------------------------------------------
	private void BindData()
	{
		DataSet ds;
		ds = GetNumeri(cboSocieta.SelectedValue.ToString());
		if (ds.Tables[0].Rows.Count > 0)
		{
			dgNumeri.DataSource = ds;
			dgNumeri.DataBind();
			dgNumeri.Visible = true;
			Panel_None.Visible = false;
			lbl_Numero.Text = ds.Tables[0].Rows.Count.ToString();
			Panel_Trovati.Visible = true;
		}
		else
		{
			Panel_None.Visible = true;
			dgNumeri.Visible = false;
			Panel_Trovati.Visible = false;
		}
		return;
	}

	public static DataSet GetNumeri(string societa)
	{
		myParameters collP = new myParameters();
		myParameter p;
		if (!string.IsNullOrEmpty(societa))
		{
			p = new myParameter("@Societa", SqlDbType.Char, 2, (string)societa);
			collP.Add((SqlParameter)p.CreateSQLParameter());
		}
		DataSet ds;
		ds = DBHelper.GetSPDataSet("BOL_sp_EstraiNumeri", collP);
		return ds;
	}


	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Visualizzazione dettaglio numerazione bolle
	//	----------------------------------------------------------------------------------------------------------------------------------------
	protected void dgNumeri_Visualizza(object source, DataGridCommandEventArgs e)
	{
		switch (e.CommandName)
		{
			case "Expand":
				dgNumeri.SelectedIndex = e.Item.ItemIndex;
				Panel_Numeri.Visible = true;
				break;

			case "Collapse":
				dgNumeri.SelectedIndex = -1;
				Panel_Numeri.Visible = false;
				break;
		}
	}

	protected void dgNumeri_Dettaglio(object source, DataGridItemEventArgs e)
	{
		if (e.Item.DataItem != null)
		{
			ListItemType itemType = e.Item.ItemType;
			System.Web.UI.Control container = e.Item;

			if (itemType == ListItemType.SelectedItem)
			{
				//	----------------------------------------------------------------------------------------------------
				//	Cambio l'immagine dell'imagebutton
				//	----------------------------------------------------------------------------------------------------
				ImageButton btnExp = (ImageButton)container.FindControl("BtnExpand");
				btnExp.ImageUrl = "~/Images/cmd_comprimi.gif";
				btnExp.CommandName = "Collapse";
				btnExp.ToolTip = "Nascondi dettagli";

				//	----------------------------------------------------------------------------------------------------
				//	Ricerca dettagli utente selezionato
				//	----------------------------------------------------------------------------------------------------
				Numeri VisNumeri = new Numeri((dgNumeri.DataKeys[e.Item.ItemIndex]).ToString());
				viCodSoc.Text = VisNumeri.ceSocieta;
				viSocieta.Text = VisNumeri.deSocieta;
				viAnno.Text = VisNumeri.ceAnno;
				viInizio.Text = VisNumeri.nmInizio;
				viFine.Text = VisNumeri.nmFine;
				viNumero.Text = VisNumeri.nmNumero;
				//
				Panel_Numeri.Visible = true;
			}
		}
	}

	//	----------------------------------------------------------------------------------------------------------------------------------------
	//	Navigazione su elenco numeri
	//	----------------------------------------------------------------------------------------------------------------------------------------
	public void dgNumeri_PageIndexChanged(object sender, DataGridPageChangedEventArgs e)
	{
		Panel_Numeri.Visible = false;
		dgNumeri.SelectedIndex = -1;
		dgNumeri.CurrentPageIndex = e.NewPageIndex;
	}

	protected void cboVisua_SelectedIndexChanged(object sender, EventArgs e)
	{
		dgNumeri.PageSize = Convert.ToInt32(cboVisua.SelectedValue);
		dgNumeri.CurrentPageIndex = 0;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Cambia selezione Societ�
	//	----------------------------------------------------------------------------------------------------
	protected void cboSocieta_SelectedIndexChanged(object sender, EventArgs e)
	{
		Panel_Numeri.Visible = false;
		dgNumeri.CurrentPageIndex = 0;
		dgNumeri.SelectedIndex = -1;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Preparazione per inserimento nuova numerazione per anno in corso
	//	----------------------------------------------------------------------------------------------------
	protected void cmdNewNumeri_OnClick(object sender, EventArgs e)
	{
		dgNumeri.Enabled = false;
		cmdNewNumeri.Visible = false;
		Panel_Nuovo.Visible = true;
		lbl_Anno.Text = DateTime.Now.Year.ToString();
		//	----------------------------------------------------------------------------------------------------
		//	Carico i DropDownList per le Societ� che si possono inserire
		//	----------------------------------------------------------------------------------------------------
		myParameter p;
		myParameters parNumeri = new myParameters();
		//
		p = new myParameter("@Anno", SqlDbType.Char, 4, DateTime.Now.Year.ToString());
		parNumeri.Add((SqlParameter)p.CreateSQLParameter());
		//
		Helper.FillDropDownList(cboNewSocie, DBHelper.GetSPDataSet("BOL_sp_EstraiSocieNum", parNumeri), "ceSocieta", "deSocieta", null, null, null);
		cboNewSocie.SelectedIndex = 0;
	}

	//	----------------------------------------------------------------------------------------------------
	//	Inserimento nuova numerazione per anno in corso
	//	----------------------------------------------------------------------------------------------------
	protected void cmdInserisci_OnClick(object sender, EventArgs e)
	{
		string str_ErrMsg = "";
		lbl_ErrorNum.Visible = false;
		

		//	----------------------------------------------------------------------------------------------------
		//	Controllo lunghezza e sequenza numero iniziale e finale bolle
		//	----------------------------------------------------------------------------------------------------
		if (txt_Inizio.Text.Length != txt_Fine.Text.Length)
		{
			str_ErrMsg = "Numero iniziale e finale devono essere lunghi uguali";
		}
		if (Convert.ToDouble(txt_Inizio.Text) >= Convert.ToDouble(txt_Fine.Text))
		{
			str_ErrMsg = "Numero finale deve essere > di numero iniziale";
		}

		//	----------------------------------------------------------------------------------------------------
		//	Se non ci sono errori si memorizzano le variabili globali
		//	----------------------------------------------------------------------------------------------------
		if (str_ErrMsg != "")
		{
			lbl_ErrorNum.Text = str_ErrMsg;
			lbl_ErrorNum.Visible = true;
		}
		else
		{
			//	----------------------------------------------------------------------------------------------------
			//	Inserimento nuovo elemento numerazione bolle
			//	----------------------------------------------------------------------------------------------------
			Numeri New_Numeri = new Numeri();
			New_Numeri.ceAnno = DateTime.Now.Year.ToString();
			New_Numeri.ceSocieta = cboNewSocie.SelectedValue.ToString();
			New_Numeri.nmInizio = txt_Inizio.Text.ToString();
			New_Numeri.nmFine = txt_Fine.Text.ToString();
			New_Numeri.InserisciNumeri();
			Panel_Nuovo.Visible = false;
			cmdNewNumeri.Visible = true;
			dgNumeri.Enabled = true;
			Carica_DropDown_Societa();
		}
	}

}
