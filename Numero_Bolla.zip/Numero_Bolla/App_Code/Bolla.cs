using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Bolla
/// </summary>
public class Bolla
{
    public string ceGID;
	public string _ceAnno;
	public string _ceProgr;
	public string _ceUtente;
	public bool _flUtente;
	public string _deFornitore;
	public DateTime _dtData;
	public string _deCDC;
	public string _ceMotivo;
	public string _deRiferimento;
	public string _ceSpedizione;
	public string _ceDestinazione;
	public string _deDestinazione;
	//
	public string _ceSocieta;
	public string _deSocieta;
	public string _deOrgUnit;
	public string _deNome;
	public string _deMotivo;
	//
	public string _utSocieta;
	public string _utSede;
	public string _utOrgUnit;


	//	----------------------------------------------------------------------------------------------------
	//	Gestione variabili comuni
	//	----------------------------------------------------------------------------------------------------

	public string ceAnno
	{
		set { _ceAnno = value; }
		get { return _ceAnno; }
	}

	public string ceProgr
	{
		set { _ceProgr = value; }
		get { return _ceProgr; }
	}

	public string ceUtente
	{
		set { _ceUtente = value; }
		get { return _ceUtente; } 
	}

	public bool flUtente
	{
		set { _flUtente = value; }
		get { return _flUtente; }
	}

	public string deFornitore
	{
		get { return _deFornitore; }
	}

	public DateTime dtData
	{
		set { _dtData = value; }
		get { return _dtData; }
	}

	public string deCDC
	{
		set { _deCDC = value; }
		get { return _deCDC; }
	}

	public string ceMotivo
	{
		set { _ceMotivo = value; }
		get { return _ceMotivo; }
	}

	public string deRiferimento
	{
		set { _deRiferimento = value; }
		get { return _deRiferimento; }
	}

	public string ceSpedizione
	{
		set { _ceSpedizione = value; }
		get { return _ceSpedizione; }
	}

	public string ceDestinazione
	{
		set { _ceDestinazione = value; }
		get { return _ceDestinazione; }
	}

	public string deDestinazione
	{
		set { _deDestinazione = value; }
		get { return _deDestinazione; }
	}


	//	----------------------------------------------------------------------------------------------------
	//	Gestione variabili per visualizzazione dettaglio
	//	----------------------------------------------------------------------------------------------------

	public string ceSocieta
	{
		set { _ceSocieta = value; }
		get { return _ceSocieta; }
	}

	public string deSocieta
	{
		get { return _deSocieta; }
	}

	public string deOrgUnit
	{
		set { _deOrgUnit = value; }
		get { return _deOrgUnit; }
	}

	public string deNome
	{
		get { return _deNome; }
	}

	public string deMotivo
	{
		get { return _deMotivo; }
	}


	//	----------------------------------------------------------------------------------------------------
	//	Gestione variabili dettaglio Informazioni utente
	//	----------------------------------------------------------------------------------------------------

	public string utSocieta
	{
		//set { _utSocieta = value; }
		get { return _utSocieta; }
	}

	public string utSede
	{
		//set { _utSocieta = value; }
		get { return _utSede; }
	}

	public string utOrgUnit
	{
		//set { _utSocieta = value; }
		get { return _utOrgUnit; }
	}


	//	----------------------------------------------------------------------------------------------------
	//	Definizione nuova bolla
	//	----------------------------------------------------------------------------------------------------
		public Bolla()
	{
		_ceAnno = null;
		_ceProgr = null;
		_ceSocieta = null;
		_deOrgUnit = null;
		_ceUtente = null;
		_flUtente = false;
		_deFornitore = null;
		_dtData = DateTime.Today;
		_deCDC = null;
		_ceMotivo = null;
		_deRiferimento = null;
		_ceSpedizione = null;
		_ceDestinazione = null;
		_deDestinazione = null;
	}


	//	----------------------------------------------------------------------------------------------------
	//	Archiviazione bolla su DataBase
	//	----------------------------------------------------------------------------------------------------
	public void SalvaBolla()
	{ 
		myParameters parBolla = new myParameters();
		myParameter par;

		par = new myParameter("@Anno", SqlDbType.Char, 4, _ceAnno);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Progr", SqlDbType.NChar, 15, _ceProgr);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Societa", SqlDbType.Char, 2, _ceSocieta);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@OrgUnit", SqlDbType.VarChar, 50, _deOrgUnit);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Utente", SqlDbType.VarChar, 16, _ceUtente);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@FlUtente", SqlDbType.Bit, 1, _flUtente);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Data", SqlDbType.DateTime, 8, _dtData);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@CentroCosto", SqlDbType.VarChar, 10, _deCDC);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Motivo", SqlDbType.NChar, 3, _ceMotivo);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Riferimento", SqlDbType.VarChar, 250, _deRiferimento);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Spedizione", SqlDbType.Char, 2, _ceSpedizione);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Destinazione", SqlDbType.Char, 2, _ceDestinazione);
		parBolla.Add(par.CreateSQLParameter());
		par = new myParameter("@Dest_Testo", SqlDbType.VarChar, 250, _deDestinazione);
		parBolla.Add(par.CreateSQLParameter());

		DBHelper.ExecuteNonQuery("BOL_sp_InsertBolla", parBolla);
	}


	//	----------------------------------------------------------------------------------------------------
	//	Lettura bolla per visualizzazione dettaglio in base al tipo:
	//					S - Storico bolle
	//					B - Bolle anno in corso
	//	----------------------------------------------------------------------------------------------------
		public void GetBolla(string bolla, string tipo)
	{
		myParameters collP = new myParameters();
		myParameter p;

		p = new myParameter("@Progr", SqlDbType.NChar, 15, bolla);
		collP.Add(p.CreateSQLParameter());
		string sqlGetBolla;
		if (tipo == "S")
		{
			sqlGetBolla = "BOL_sp_GetBollaSt";
		}
		else
		{
			sqlGetBolla = "BOL_sp_GetBolla";
		}
		SqlDataReader dr = DBHelper.GetSPReader(sqlGetBolla, collP);

		if ((dr != null) && dr.Read())
		{
			_ceAnno = dr["ceAnno"].ToString();
			_ceProgr = dr["ceProgr"].ToString();
			_deSocieta = dr["deSocieta"].ToString();
			_deOrgUnit = dr["deOrgUnit"].ToString();
			_deCDC = dr["ceCDC"].ToString();
			//
			_ceUtente = dr["ceUtente"].ToString();
			_deNome = dr["deNome"].ToString();
			_flUtente = Convert.ToBoolean(dr["flUtente"]);
			_deFornitore = dr["deFornitore"].ToString();
			_utSocieta = dr["utSocieta"].ToString();
			_utSede = dr["utSede"].ToString();
			_utOrgUnit = dr["utOrgUnit"].ToString();
			//
			_deMotivo = dr["deMotivo"].ToString();
			_deRiferimento = dr["deRiferimento"].ToString();
			_ceSpedizione = dr["ceSpedizione"].ToString();
			_ceDestinazione = dr["ceDestinazione"].ToString();
			_deDestinazione = dr["deDestinazione"].ToString();
		}
		else
		{
			_ceProgr = "";
		}
		dr.Close();
	}
}
