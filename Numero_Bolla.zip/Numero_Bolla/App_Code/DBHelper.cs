using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DBHelper
/// </summary>
public class DBHelper
{
	public DBHelper()
	{
		//
		// TODO: Add constructor logic here
		//
	}

	public static SqlDataReader GetSPReader(String sp_name, myParameters collP)
	{
		SqlCommand comm;
		SqlDataReader dr;
		try
		{
			//SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["connString"]);
            SqlConnection conn = new SqlConnection(CurrentEnvironment.CurrentEnvironment.DbConnectionString);
			if (conn.State != ConnectionState.Open)
				conn.Open();
			comm = new SqlCommand(sp_name, conn);
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.Clear();
			if (collP != null)
			{
				foreach (SqlParameter p in collP)
					comm.Parameters.Add(p);
			}
			dr = comm.ExecuteReader(CommandBehavior.CloseConnection);
		}
		catch (SqlException e)
		{
			throw new Exception(e.Message, e);
		}
		return dr;
	}

	public static DataSet GetSPDataSet(string sp_name, myParameters collP)
	{
		SqlCommand comm;
		DataSet ds = new DataSet();
		SqlDataAdapter da = new SqlDataAdapter();

		try
		{
			//SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["connString"]);
            SqlConnection conn = new SqlConnection(CurrentEnvironment.CurrentEnvironment.DbConnectionString);
            if (conn.State != ConnectionState.Open)
				conn.Open();
			comm = new SqlCommand(sp_name, conn);
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.Clear();
			if (collP != null)
			{
				foreach (SqlParameter p in collP)
					comm.Parameters.Add(p);
			}
			da.SelectCommand = comm;
			da.Fill(ds);
			if (conn.State != ConnectionState.Closed)
				conn.Close();
		}
		catch (SqlException e)
		{
			throw new Exception(e.Message, e);
		}
		return ds;
	}

	public static DataSet GetSPDataSet(string sp_name)
	{
		SqlCommand comm;
		DataSet ds = new DataSet();
		SqlDataAdapter da = new SqlDataAdapter();

		try
		{
			//SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["connString"]);
            SqlConnection conn = new SqlConnection(CurrentEnvironment.CurrentEnvironment.DbConnectionString);
            if (conn.State != ConnectionState.Open)
				conn.Open();
			comm = new SqlCommand(sp_name, conn);
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.Clear();
			da.SelectCommand = comm;
			da.Fill(ds);
			if (conn.State != ConnectionState.Closed)
				conn.Close();
		}
		catch (SqlException e)
		{
			throw new Exception(e.Message, e);
		}
		return ds;
	}

	public static void ExecuteNonQuery(string sp_name, myParameters collP)
	{
		SqlCommand comm;

		try
		{
			//SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationManager.AppSettings["connString"]);
            SqlConnection conn = new SqlConnection(CurrentEnvironment.CurrentEnvironment.DbConnectionString);
            if (conn.State != ConnectionState.Open)
				conn.Open();
			comm = new SqlCommand(sp_name, conn);
			comm.CommandType = CommandType.StoredProcedure;
			comm.Parameters.Clear();
			foreach (SqlParameter p in collP)
				comm.Parameters.Add(p);
			comm.ExecuteNonQuery();
			if (conn.State != ConnectionState.Closed)
				conn.Close();
			conn.Dispose();
			comm.Dispose();
		}
		catch (SqlException e)
		{
			throw new Exception(e.Message, e);
		}
	}

}

public class myParameter
{
	string _ParamName;
	SqlDbType _Type;
	int _Size;
	object _Value;

	public myParameter(string par_strName, SqlDbType par_Type, int par_intSize, object par_objObject)
	{
		_ParamName = par_strName;
		_Type = par_Type;
		_Size = par_intSize;
		_Value = par_objObject;
	}

	public SqlParameter CreateSQLParameter()
	{
		SqlParameter p = new SqlParameter();
		p.ParameterName = _ParamName;
		p.SqlDbType = _Type;
		p.Size = _Size;
		p.Value = _Value;

		return p;
	}

}

public class myParameters : System.Collections.CollectionBase
{
	public SqlParameter this[int index]
	{
		get
		{
			return (SqlParameter)this[index];
		}
		set
		{
			List[index] = value;
		}
	}

	public void Add(SqlParameter p)
	{
		List.Add(p);
	}

	public void Remove(SqlParameter p)
	{
		List.Remove(p);
	}
}